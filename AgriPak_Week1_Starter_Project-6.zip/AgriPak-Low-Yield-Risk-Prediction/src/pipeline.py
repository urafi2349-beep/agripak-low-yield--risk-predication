"""
Week 1 pipeline for AgriPak Farms.
Usage:
    python src/pipeline.py --data data/raw/crop_data.csv --target TARGET_COLUMN
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="data/raw/crop_data.csv")
    parser.add_argument("--target", required=True, help="Target column name in CSV")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    data_path = Path(args.data)
    out_dir = Path("data/processed")
    out_dir.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(data_path)
    df.columns = df.columns.str.strip()

    if args.target not in df.columns:
        raise ValueError(f"Target '{args.target}' not found. Columns: {list(df.columns)}")

    # Remove duplicate records.
    before = len(df)
    df = df.drop_duplicates().copy()
    duplicates_removed = before - len(df)

    # Drop rows where target is missing: target cannot be imputed for supervised learning.
    missing_target = int(df[args.target].isna().sum())
    df = df.dropna(subset=[args.target]).copy()

    # Trim whitespace in text columns and convert blank strings to missing values.
    text_cols = df.select_dtypes(include=["object", "string"]).columns
    for col in text_cols:
        df[col] = df[col].astype("string").str.strip()
        df[col] = df[col].replace("", pd.NA)

    # Infer numeric types when values can be parsed consistently.
    for col in df.columns:
        if col == args.target:
            continue
        if df[col].dtype == "object" or str(df[col].dtype) == "string":
            converted = pd.to_numeric(df[col], errors="coerce")
            nonmissing_original = df[col].notna().sum()
            if nonmissing_original and converted.notna().sum() / nonmissing_original >= 0.90:
                df[col] = converted

    # Save cleaned dataset (imputation is fitted later on training data only).
    df.to_csv(out_dir / "cleaned_data.csv", index=False)

    X = df.drop(columns=[args.target])
    y = df[args.target]

    # Stratification requires each class to have enough samples.
    class_counts = y.value_counts()
    if class_counts.min() < 2:
        raise ValueError("Each target class needs at least 2 rows for stratified splitting.")

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=args.seed, stratify=y
    )

    train_df = X_train.copy()
    train_df[args.target] = y_train
    test_df = X_test.copy()
    test_df[args.target] = y_test
    train_df.to_csv(out_dir / "train.csv", index=False)
    test_df.to_csv(out_dir / "test.csv", index=False)

    # Preprocessing is learned from training data only to prevent test-data leakage.
    numeric_cols = X_train.select_dtypes(include=np.number).columns.tolist()
    categorical_cols = [c for c in X_train.columns if c not in numeric_cols]

    numeric_pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])
    categorical_pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore"))
    ])

    prep = ColumnTransformer([
        ("numeric", numeric_pipeline, numeric_cols),
        ("categorical", categorical_pipeline, categorical_cols)
    ])

    model = Pipeline([
        ("preprocessing", prep),
        ("classifier", LogisticRegression(max_iter=1000))
    ])
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    # Binary metrics; for multiclass, use macro averages.
    average = "binary" if y.nunique() == 2 else "macro"
    if average == "binary" and set(pd.unique(y)) != {0, 1}:
        # sklearn's binary metrics support labels like strings, but explicitly set pos_label.
        positive_label = sorted(pd.unique(y), key=str)[-1]
        precision = precision_score(y_test, predictions, pos_label=positive_label, zero_division=0)
        recall = recall_score(y_test, predictions, pos_label=positive_label, zero_division=0)
        f1 = f1_score(y_test, predictions, pos_label=positive_label, zero_division=0)
    else:
        precision = precision_score(y_test, predictions, average=average, zero_division=0)
        recall = recall_score(y_test, predictions, average=average, zero_division=0)
        f1 = f1_score(y_test, predictions, average=average, zero_division=0)

    scores = {
        "accuracy": float(accuracy_score(y_test, predictions)),
        "precision": float(precision),
        "recall": float(recall),
        "f1": float(f1),
        "target_column": args.target,
        "random_seed": args.seed,
        "train_rows": len(X_train),
        "test_rows": len(X_test),
    }
    with open(out_dir / "baseline_metrics.json", "w", encoding="utf-8") as f:
        json.dump(scores, f, indent=2)

    # First-pass leakage scan: numeric features correlated with encoded target.
    # For categorical targets, factorization is only a screening heuristic, not proof.
    y_encoded, target_labels = pd.factorize(y)
    scan_df = X.copy()
    scan_df["_encoded_target"] = y_encoded
    numeric_scan = scan_df.select_dtypes(include=np.number)
    correlations = numeric_scan.corr(numeric_only=True)["_encoded_target"].drop("_encoded_target")
    leakage_report = correlations.abs().sort_values(ascending=False).rename("abs_correlation").to_frame()
    leakage_report["correlation"] = correlations.loc[leakage_report.index]
    leakage_report["flag_over_0.9"] = leakage_report["abs_correlation"] > 0.90
    leakage_report.to_csv(out_dir / "leakage_scan.csv")

    print("Baseline metrics:")
    print(json.dumps(scores, indent=2))
    print("\nLeakage candidates (absolute correlation > 0.90):")
    print(leakage_report[leakage_report["flag_over_0.9"]])
    print("\nCleaning summary:")
    print(f"Duplicates removed: {duplicates_removed}")
    print(f"Rows removed for missing target: {missing_target}")
    print(f"Target encoding for leakage scan: {list(map(str, target_labels))}")


if __name__ == "__main__":
    main()
