# AgriPak Farms — Low-Yield Risk Prediction

## Week 1: Repository, data cleaning, baseline, and leakage sanity check

### Objective
Build an initial machine-learning baseline to flag fields at risk of low yield before harvest.

### Repository layout
- `data/raw/`: original dataset (do not edit the source file)
- `data/processed/`: cleaned data, reproducible train/test splits, metrics and leakage scan
- `src/pipeline.py`: end-to-end Week 1 pipeline
- `notebooks/`: exploratory analysis

### Setup
```bash
pip install pandas numpy scikit-learn matplotlib seaborn
```

Put the provided `crop_data.csv` in `data/raw/`.

### Run
Replace `TARGET_COLUMN` with the actual target column name:
```bash
python src/pipeline.py --data data/raw/crop_data.csv --target TARGET_COLUMN
```

The split is stratified, 80/20, and uses random seed 42. Re-running with the same dataset and seed reproduces the split.

### Cleaning decisions
1. Duplicate rows are removed.
2. Rows with a missing target are removed because the supervised label is unknown.
3. Leading/trailing spaces in text values are trimmed; empty text is treated as missing.
4. Text-like columns that are at least 90% parseable as numeric are converted to numeric.
5. Missing numeric features are imputed with the training-set median.
6. Missing categorical features are imputed with the training-set most frequent value.
7. Categorical features are one-hot encoded; unknown test categories are ignored.
8. Numeric features are standardized. Preprocessing is fitted only on training data.

These are the pipeline's documented rules. Review them against the actual dataset and revise if a column has a special meaning (e.g., IDs, dates, post-harvest variables).

### Outputs
- `data/processed/cleaned_data.csv`
- `data/processed/train.csv`
- `data/processed/test.csv`
- `data/processed/baseline_metrics.json`
- `data/processed/leakage_scan.csv`

### Baseline metrics
Fill in these results after running the pipeline:
- Accuracy: TODO
- Precision: TODO
- Recall: TODO
- F1: TODO

### Leakage sanity check
The script creates a numeric correlation screening report and flags absolute correlation above 0.90. Correlation alone does not prove leakage. Inspect each flagged feature and ask:
- Would this feature be available before harvest and at prediction time?
- Was it calculated using the yield/target or information recorded after harvest?
- Is it a field ID or other proxy rather than a genuine agronomic predictor?

Write the final judgment for each flagged column here after inspecting its meaning:
- Flagged columns: TODO
- Leakage or genuine predictor? Reason: TODO

**Note:** If the target is categorical, the correlation scan factorizes its labels into integer codes. This is only a screening heuristic and can be misleading for multiclass labels; investigate flagged columns and use appropriate statistical checks for a stronger analysis.

### Week 1 submission summary
TODO: Add 2–3 sentences summarizing test metrics and leakage findings.
